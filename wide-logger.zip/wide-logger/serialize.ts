import { REDACTED, type KeyPredicate } from './redact';
import type { ErrorInfo } from './types';

export interface SanitizeOptions {
  isSensitive: KeyPredicate;
  maxStringLength: number;
  includeStack: boolean;
  maxDepth?: number;
  maxArrayLength?: number;
}

type AnyRecord = Record<string, unknown>;
type RawError = Error & AnyRecord;

const DEFAULT_MAX_DEPTH = 12;
const DEFAULT_MAX_ARRAY = 100;
const MAX_CAUSE_DEPTH = 3;
/** Chaves próprias do erro que já são tratadas à parte ou que só carregam ruído. */
const IGNORED_ERROR_KEYS = new Set(['stack', 'message', 'name', 'cause', '$metadata', '$response']);
const AXIOS_SKIP_KEYS = new Set(['config', 'request', 'response', 'isAxiosError', 'toJSON']);
/** Marca "não é primitivo" (o valor sanitizado de um primitivo pode ser `undefined`). */
const NOT_PRIMITIVE = Symbol('not-primitive');

export function truncate(value: string, max: number): string {
  if (value.length <= max) return value;
  return `${value.slice(0, max)}…[truncated ${value.length - max} chars]`;
}

function readRetriable(err: AnyRecord): boolean | undefined {
  if (typeof err.retriable === 'boolean') return err.retriable;
  if (typeof err.retryable === 'boolean') return err.retryable;
  // AWS SDK v3 expõe `$retryable` quando o erro pode ser repetido.
  if (err.$retryable !== undefined) return Boolean(err.$retryable);
  return undefined;
}

function safeString(value: unknown): string {
  try {
    return JSON.stringify(value) ?? String(value);
  } catch {
    return String(value);
  }
}

/** Valores lançados que não são `Error` (string, objeto literal...). */
function serializeNonError(err: unknown): ErrorInfo {
  if (err !== null && typeof err === 'object') {
    const obj = err as AnyRecord;
    return {
      type: typeof obj.name === 'string' ? obj.name : 'NonError',
      message: typeof obj.message === 'string' ? obj.message : safeString(err),
    };
  }
  return { type: 'NonError', message: String(err) };
}

/** Propriedades próprias (ex.: statusCode, declineCode) carregam contexto valioso. */
function copyOwnProperties(info: ErrorInfo, raw: RawError, isAxios: boolean): void {
  for (const key of Object.keys(raw)) {
    if (IGNORED_ERROR_KEYS.has(key) || (isAxios && AXIOS_SKIP_KEYS.has(key))) continue;
    info[key] = raw[key];
  }
}

function axiosUrl(config: { url?: string; baseURL?: string } | undefined): string | undefined {
  if (!config?.url) return undefined;
  const isRelative = !/^https?:/i.test(config.url);
  return config.baseURL && isRelative ? `${config.baseURL}${config.url}` : config.url;
}

/** Erros do axios carregam request/config inteiros (sockets, agent, certificados): fica só o essencial. */
function addAxiosFields(info: ErrorInfo, raw: RawError): void {
  const config = raw.config as { method?: string; url?: string; baseURL?: string } | undefined;
  const response = raw.response as { status?: number; data?: unknown } | undefined;
  if (config?.method) info.http_method = config.method.toUpperCase();
  const url = axiosUrl(config);
  if (url) info.url = url;
  if (response?.status !== undefined) info.http_status_code = response.status;
  if (response?.data !== undefined) info.response_data = response.data;
}

/** `code`, `retriable` e os metadados do AWS SDK v3 (`$metadata`). */
function addErrorMetadata(info: ErrorInfo, raw: RawError): void {
  if (typeof raw.code === 'string' || typeof raw.code === 'number') info.code = raw.code;

  const retriable = readRetriable(raw);
  if (retriable !== undefined) info.retriable = retriable;

  const metadata = raw.$metadata as { httpStatusCode?: number; requestId?: string } | undefined;
  if (metadata?.httpStatusCode !== undefined) info.http_status_code = metadata.httpStatusCode;
  if (metadata?.requestId !== undefined) info.aws_request_id = metadata.requestId;
}

/** Converte qualquer coisa lançada (Error ou não) em um objeto estruturado. */
export function serializeError(err: unknown, includeStack = true, depth = 0): ErrorInfo {
  if (!(err instanceof Error)) return serializeNonError(err);

  const raw = err as RawError;
  const info: ErrorInfo = { type: err.name || err.constructor?.name || 'Error', message: err.message };
  const isAxios = raw.isAxiosError === true;

  copyOwnProperties(info, raw, isAxios);
  if (isAxios) addAxiosFields(info, raw);
  addErrorMetadata(info, raw);

  if (includeStack && err.stack) info.stack = err.stack;
  if (raw.cause !== undefined && depth < MAX_CAUSE_DEPTH) {
    info.cause = serializeError(raw.cause, includeStack, depth + 1);
  }
  return info;
}

/** Sanitiza primitivos; para objetos (exceto `null`) retorna {@link NOT_PRIMITIVE}. */
function sanitizePrimitive(val: unknown, maxStringLength: number): unknown {
  switch (typeof val) {
    case 'string':
      return truncate(val, maxStringLength);
    case 'number':
      return Number.isFinite(val) ? val : String(val);
    case 'boolean':
      return val;
    case 'bigint':
    case 'symbol':
      return val.toString();
    case 'undefined':
    case 'function':
      return undefined;
    default:
      return val === null ? null : NOT_PRIMITIVE;
  }
}

/** Objetos convertidos direto em texto (sem percorrer propriedades). */
function sanitizeLeafObject(obj: object): string | undefined {
  if (obj instanceof Date) return Number.isNaN(obj.getTime()) ? 'Invalid Date' : obj.toISOString();
  if (Buffer.isBuffer(obj)) return `[Buffer ${obj.length} bytes]`;
  return undefined;
}

/**
 * Prepara um valor para JSON: redige chaves sensíveis, trunca strings, trata
 * referências circulares, Errors, Dates, BigInt, Map/Set e Buffers.
 */
export function sanitize(value: unknown, opts: SanitizeOptions): unknown {
  const maxDepth = opts.maxDepth ?? DEFAULT_MAX_DEPTH;
  const maxArray = opts.maxArrayLength ?? DEFAULT_MAX_ARRAY;
  const ancestors: object[] = [];

  const walkArray = (arr: unknown[], depth: number): unknown[] => {
    const out = arr.slice(0, maxArray).map((item) => walk(item, depth + 1) ?? null);
    if (arr.length > maxArray) out.push(`…(${arr.length - maxArray} more)`);
    return out;
  };

  const walkEntries = (obj: object, depth: number): AnyRecord => {
    const out: AnyRecord = {};
    for (const [key, child] of Object.entries(obj)) {
      if (opts.isSensitive(key)) {
        if (child !== undefined && child !== null) out[key] = REDACTED;
        continue;
      }
      const res = walk(child, depth + 1);
      if (res !== undefined) out[key] = res;
    }
    return out;
  };

  const walkObject = (obj: object, depth: number): unknown => {
    if (obj instanceof Error) return walk(serializeError(obj, opts.includeStack), depth + 1);
    if (obj instanceof Map) return walk(Object.fromEntries(obj), depth);
    if (obj instanceof Set) return walk([...obj], depth);
    if (Array.isArray(obj)) return walkArray(obj, depth);

    const toJSON = (obj as { toJSON?: unknown }).toJSON;
    const source = typeof toJSON === 'function' ? toJSON.call(obj) : obj;
    if (source !== obj) return walk(source, depth + 1);

    return walkEntries(obj, depth);
  };

  const walk = (val: unknown, depth: number): unknown => {
    const primitive = sanitizePrimitive(val, opts.maxStringLength);
    if (primitive !== NOT_PRIMITIVE) return primitive;

    const obj = val as object;
    const leaf = sanitizeLeafObject(obj);
    if (leaf !== undefined) return leaf;
    if (ancestors.includes(obj)) return '[Circular]';
    if (depth >= maxDepth) return '[MaxDepth]';

    ancestors.push(obj);
    try {
      return walkObject(obj, depth);
    } finally {
      ancestors.pop();
    }
  };

  return walk(value, 0);
}
