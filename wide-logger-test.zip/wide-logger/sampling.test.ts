import { shouldSample, WideEvent } from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger';
import { captureLogger, fakeContext } from './helpers';

const newEvent = () => new WideEvent({ minLevel: 'info', maxLogs: 10, includeStack: true });
const base = { durationMs: 10, slowThresholdMs: 1000, random: () => 0.99 };

describe('shouldSample', () => {
  it('sempre mantém erros, lentos e warns mesmo com rate 0', () => {
    expect(shouldSample({ ...base, event: newEvent(), level: 'error', sampleRate: 0 })).toMatchObject({ keep: true, reason: 'error' });
    expect(shouldSample({ ...base, event: newEvent(), level: 'info', sampleRate: 0, durationMs: 5000 })).toMatchObject({ keep: true, reason: 'slow' });
    expect(shouldSample({ ...base, event: newEvent(), level: 'warn', sampleRate: 0 })).toMatchObject({ keep: true, reason: 'warn' });
  });

  it('aplica a regra keep customizada (com motivo)', () => {
    const event = newEvent().set({ user: { tier: 'vip' } });
    const keep = (e: WideEvent) => (e.get('user.tier') === 'vip' ? 'vip_user' : false);
    expect(shouldSample({ ...base, event, level: 'info', sampleRate: 0, keep })).toMatchObject({ keep: true, reason: 'vip_user' });
  });

  it('regra keep que lança erro é ignorada', () => {
    const keep = () => {
      throw new Error('bug');
    };
    expect(shouldSample({ ...base, event: newEvent(), level: 'info', sampleRate: 0, keep }).keep).toBe(false);
  });

  it('amostra o restante pela taxa', () => {
    expect(shouldSample({ ...base, event: newEvent(), level: 'info', sampleRate: 0.05, random: () => 0.01 })).toMatchObject({ keep: true, reason: 'sampled' });
    expect(shouldSample({ ...base, event: newEvent(), level: 'info', sampleRate: 0.05, random: () => 0.5 })).toMatchObject({ keep: false, reason: 'dropped' });
  });
});

describe('sampling integrado ao logger', () => {
  it('descarta invocações felizes e mantém as com erro', async () => {
    const { logger, records } = captureLogger({ sampleRate: 0.05, random: () => 0.9 });
    await logger.withWideEvent(async () => 'ok')({}, fakeContext());
    await logger
      .withWideEvent(async () => {
        throw new Error('x');
      })({}, fakeContext())
      .catch(() => undefined);
    expect(records().map((r) => r.outcome)).toEqual(['error']);
  });

  it('invocação lenta vira warn e é mantida', async () => {
    const { logger, records } = captureLogger({ sampleRate: 0, slowThresholdMs: 1 });
    await logger.withWideEvent(async () => {
      await new Promise((r) => setTimeout(r, 15));
      return 'ok';
    })({}, fakeContext());
    expect(records()[0]).toMatchObject({ level: 'warn', sampling: { reason: 'slow' } });
  });
});

describe('shouldSample - regras keep e rate', () => {
  const info = { ...base, level: 'info' as const };

  it('keep que retorna true usa o motivo keep_rule', () => {
    expect(shouldSample({ ...info, event: newEvent(), sampleRate: 0, keep: () => true })).toEqual({
      keep: true,
      reason: 'keep_rule',
      rate: 0,
    });
  });

  it('keep que retorna falso ou lança erro cai na amostragem normal', () => {
    expect(shouldSample({ ...info, event: newEvent(), sampleRate: 0, keep: () => false })).toMatchObject({ keep: false, reason: 'dropped' });
    const quebrada = () => {
      throw new Error('bug');
    };
    expect(shouldSample({ ...info, event: newEvent(), sampleRate: 1, keep: quebrada })).toMatchObject({ keep: true, reason: 'all' });
  });

  it('amostra aleatoriamente entre 0 e 1', () => {
    expect(shouldSample({ ...info, event: newEvent(), sampleRate: 0.5, random: () => 0.1 })).toMatchObject({ keep: true, reason: 'sampled' });
    expect(shouldSample({ ...info, event: newEvent(), sampleRate: 0.5, random: () => 0.9 })).toMatchObject({ keep: false, reason: 'dropped' });
  });
});
