import { sanitize, serializeError } from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger';
import { createRedactor } from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/redact';

const opts = { isSensitive: createRedactor(), maxStringLength: 20, includeStack: false };

describe('sanitize', () => {
  it('trata referências circulares sem marcar referências compartilhadas', () => {
    const shared = { a: 1 };
    const obj: Record<string, unknown> = { x: shared, y: shared };
    obj.self = obj;
    expect(sanitize(obj, opts)).toEqual({ x: { a: 1 }, y: { a: 1 }, self: '[Circular]' });
  });

  it('converte tipos especiais', () => {
    const out = sanitize(
      {
        date: new Date('2026-01-01T00:00:00Z'),
        big: 10n,
        map: new Map([['k', 'v']]),
        set: new Set([1, 2]),
        buf: Buffer.from('abc'),
        fn: () => 1,
        nan: Number.NaN,
      },
      opts,
    );
    expect(out).toEqual({
      date: '2026-01-01T00:00:00.000Z',
      big: '10',
      map: { k: 'v' },
      set: [1, 2],
      buf: '[Buffer 3 bytes]',
      nan: 'NaN',
    });
  });

  it('trunca strings longas', () => {
    expect(sanitize('a'.repeat(30), opts)).toBe(`${'a'.repeat(20)}…[truncated 10 chars]`);
  });

  it('redige chaves com variações de caixa e separadores', () => {
    expect(sanitize({ Authorization: 'x', 'x-api-key': 'y', access_token: 'z', ok: 1 }, opts)).toEqual({
      Authorization: '[REDACTED]',
      'x-api-key': '[REDACTED]',
      access_token: '[REDACTED]',
      ok: 1,
    });
  });
});

describe('serializeError', () => {
  it('inclui propriedades próprias, code, cause e metadados do AWS SDK', () => {
    const cause = new TypeError('timeout');
    const err = Object.assign(new Error('falha DynamoDB', { cause }), {
      name: 'ProvisionedThroughputExceededException',
      $retryable: { throttling: true },
      $metadata: { httpStatusCode: 400, requestId: 'aws-req-1' },
      tableName: 'apolices',
    });
    const info = serializeError(err, false);
    expect(info).toEqual({
      type: 'ProvisionedThroughputExceededException',
      message: 'falha DynamoDB',
      $retryable: { throttling: true },
      tableName: 'apolices',
      retriable: true,
      http_status_code: 400,
      aws_request_id: 'aws-req-1',
      cause: { type: 'TypeError', message: 'timeout' },
    });
  });

  it('lida com valores que não são Error', () => {
    expect(serializeError('boom')).toEqual({ type: 'NonError', message: 'boom' });
    expect(serializeError({ name: 'Custom', message: 'm' })).toEqual({ type: 'Custom', message: 'm' });
  });
});

describe('serializeError com axios', () => {
  it('mantém só método, url, status e corpo da resposta', () => {
    const err = Object.assign(new Error('Request failed with status code 502'), {
      name: 'AxiosError',
      code: 'ERR_BAD_RESPONSE',
      isAxiosError: true,
      config: { method: 'post', url: 'https://parceiro/api', headers: { Authorization: 'Bearer x' }, httpsAgent: { ca: 'CERT' } },
      request: { socket: {} },
      response: { status: 502, data: { message: 'bad gateway' }, headers: {} },
    });
    const info = serializeError(err, false);
    expect(info).toEqual({
      type: 'AxiosError',
      message: 'Request failed with status code 502',
      code: 'ERR_BAD_RESPONSE',
      http_method: 'POST',
      url: 'https://parceiro/api',
      http_status_code: 502,
      response_data: { message: 'bad gateway' },
    });
  });
});

describe('createRedactor', () => {
  it('sem defaults e sem chaves extras não redige nada', () => {
    const isSensitive = createRedactor([], false);
    expect(isSensitive('password')).toBe(false);
  });

  it('aceita chaves extras, com ou sem os defaults', () => {
    const onlyExtra = createRedactor(['Numero-Apolice'], false);
    expect(onlyExtra('numero_apolice')).toBe(true);
    expect(onlyExtra('password')).toBe(false);

    const withDefaults = createRedactor(['numeroApolice']);
    expect(withDefaults('NUMERO_APOLICE')).toBe(true);
    expect(withDefaults('senha')).toBe(true);
  });
});

describe('serializeError - não Error', () => {
  it('usa NonError e o JSON do objeto quando não há name/message em texto', () => {
    expect(serializeError({ code: 1, name: 123 })).toEqual({ type: 'NonError', message: '{"code":1,"name":123}' });
  });

  it('cai para String() quando o JSON.stringify falha', () => {
    const circular: Record<string, unknown> = {};
    circular.self = circular;
    expect(serializeError(circular)).toEqual({ type: 'NonError', message: '[object Object]' });
  });

  it('cai para String() quando o JSON.stringify retorna undefined', () => {
    expect(serializeError({ toJSON: () => undefined })).toEqual({ type: 'NonError', message: '[object Object]' });
  });

  it('converte null, undefined e números', () => {
    expect(serializeError(null)).toEqual({ type: 'NonError', message: 'null' });
    expect(serializeError(undefined)).toEqual({ type: 'NonError', message: 'undefined' });
    expect(serializeError(42)).toEqual({ type: 'NonError', message: '42' });
  });
});

describe('serializeError - Error', () => {
  it('usa o nome do construtor quando name está vazio', () => {
    class MeuErro extends Error {}
    const err = new MeuErro('x');
    err.name = '';
    expect(serializeError(err, false).type).toBe('MeuErro');
  });

  it('usa "Error" quando não há name nem construtor', () => {
    const err = new Error('x');
    err.name = '';
    Object.defineProperty(err, 'constructor', { value: undefined });
    expect(serializeError(err, false).type).toBe('Error');
  });

  it('ignora stack/message/name/cause/$response próprios e enumeráveis', () => {
    const err = new Error('original');
    Object.assign(err, { stack: 's', message: 'm', name: 'N', cause: undefined, $response: { body: 'grande' }, extra: 1 });
    expect(serializeError(err, false)).toEqual({ type: 'N', message: 'm', extra: 1 });
  });

  it('inclui o stack só com includeStack e stack presente', () => {
    const err = new Error('x');
    expect(serializeError(err).stack).toBe(err.stack);
    expect(serializeError(err, false).stack).toBeUndefined();

    const semStack = new Error('x');
    semStack.stack = '';
    expect(serializeError(semStack, true).stack).toBeUndefined();
  });

  it('aceita code numérico e ignora code de outros tipos', () => {
    expect(serializeError(Object.assign(new Error('x'), { code: 503 }), false).code).toBe(503);
    expect(serializeError(new Error('x'), false)).not.toHaveProperty('code');
  });

  it.each([
    [{ retriable: false }, false],
    [{ retryable: true }, true],
    [{ $retryable: 0 }, false],
    [{}, undefined],
  ])('lê retriable de %p', (props, expected) => {
    expect(serializeError(Object.assign(new Error('x'), props), false).retriable).toBe(expected);
  });

  it('ignora campos ausentes no $metadata', () => {
    const info = serializeError(Object.assign(new Error('x'), { $metadata: {} }), false);
    expect(info).not.toHaveProperty('http_status_code');
    expect(info).not.toHaveProperty('aws_request_id');
  });

  it('para de serializar a cause na profundidade máxima', () => {
    const e4 = new Error('e4');
    const e3 = new Error('e3', { cause: e4 });
    const e2 = new Error('e2', { cause: e3 });
    const e1 = new Error('e1', { cause: e2 });
    const e0 = new Error('e0', { cause: e1 });

    const info = serializeError(e0, false);
    expect(info.cause?.cause?.cause).toEqual({ type: 'Error', message: 'e3' });
  });
});

describe('serializeError com axios - variações', () => {
  const axiosError = (props: Record<string, unknown>) =>
    Object.assign(new Error('falhou'), { name: 'AxiosError', isAxiosError: true, ...props });

  it('junta baseURL com url relativa', () => {
    const info = serializeError(axiosError({ config: { method: 'get', baseURL: 'https://api', url: '/cotacoes' } }), false);
    expect(info).toMatchObject({ http_method: 'GET', url: 'https://api/cotacoes' });
  });

  it('não junta baseURL quando a url já é absoluta', () => {
    const info = serializeError(axiosError({ config: { baseURL: 'https://api', url: 'HTTP://outra/x' } }), false);
    expect(info.url).toBe('HTTP://outra/x');
    expect(info).not.toHaveProperty('http_method');
  });

  it('usa a url como está sem baseURL', () => {
    expect(serializeError(axiosError({ config: { url: '/x' } }), false).url).toBe('/x');
  });

  it('não quebra sem config nem response', () => {
    expect(serializeError(axiosError({}), false)).toEqual({ type: 'AxiosError', message: 'falhou' });
  });

  it('ignora config sem url e response sem status/data', () => {
    const info = serializeError(axiosError({ config: { method: 'put' }, response: {} }), false);
    expect(info).toEqual({ type: 'AxiosError', message: 'falhou', http_method: 'PUT' });
  });
});

describe('sanitize - casos de borda', () => {
  it('troca funções dentro de arrays por null', () => {
    expect(sanitize([1, () => 1, 'a'], opts)).toEqual([1, null, 'a']);
  });

  it('serializa Error dentro de objetos', () => {
    expect(sanitize({ err: new Error('x') }, opts)).toEqual({ err: { type: 'Error', message: 'x' } });
  });

  it('não marca como REDACTED chaves sensíveis com valor null/undefined', () => {
    expect(sanitize({ senha: null, token: undefined, cpf: '123' }, opts)).toEqual({ cpf: '[REDACTED]' });
  });

  it('percorre normalmente objetos cujo toJSON retorna o próprio objeto', () => {
    const obj: Record<string, unknown> = { a: 1 };
    obj.toJSON = () => obj;
    expect(sanitize(obj, opts)).toEqual({ a: 1 });
  });

  it('mantém primitivos como estão', () => {
    expect(sanitize('texto', opts)).toBe('texto');
    expect(sanitize(null, opts)).toBeNull();
  });
});

describe('sanitize - tipos e limites da versão completa', () => {
  it('mantém números finitos e booleanos, converte Infinity e Symbol em texto', () => {
    expect(sanitize({ n: 1.5, b: true, inf: Infinity, s: Symbol('x') }, opts)).toEqual({
      n: 1.5,
      b: true,
      inf: 'Infinity',
      s: 'Symbol(x)',
    });
  });

  it('descarta undefined em objetos e troca por null em arrays', () => {
    expect(sanitize({ a: undefined, arr: [undefined] }, opts)).toEqual({ arr: [null] });
  });

  it('marca datas inválidas', () => {
    expect(sanitize(new Date('não é data'), opts)).toBe('Invalid Date');
  });

  it('corta objetos acima do maxDepth', () => {
    expect(sanitize({ a: { b: { c: 1 } } }, { ...opts, maxDepth: 2 })).toEqual({ a: { b: '[MaxDepth]' } });
  });

  it('corta arrays acima do maxArrayLength', () => {
    expect(sanitize([1, 2, 3, 4], { ...opts, maxArrayLength: 2 })).toEqual([1, 2, '…(2 more)']);
  });

  it('usa o retorno do toJSON de objetos customizados', () => {
    expect(sanitize({ valor: { toJSON: () => ({ centavos: 100, senha: 'x' }) } }, opts)).toEqual({
      valor: { centavos: 100, senha: '[REDACTED]' },
    });
  });

  it('usa os limites padrão quando não informados', () => {
    const arr = Array.from({ length: 101 }, (_, i) => i);
    const out = sanitize(arr, opts) as unknown[];
    expect(out).toHaveLength(101);
    expect(out[100]).toBe('…(1 more)');
  });
});
