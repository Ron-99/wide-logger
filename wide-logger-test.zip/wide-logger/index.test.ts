import * as lib from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger';
import * as context from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/context';
import * as correlation from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/enrichers/correlation';
import * as detect from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/enrichers/detect';
import * as levels from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/levels';
import * as logger from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/logger';
import * as pino from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/pino';
import * as redact from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/redact';
import * as sampling from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/sampling';
import * as serialize from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/serialize';
import * as transport from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/transport';
import * as wideEvent from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/wide-event';

describe('index (API pública)', () => {
  it.each([
    ['createLogger', logger.createLogger],
    ['WideEvent', wideEvent.WideEvent],
    ['summarizeWideEvent', wideEvent.summarizeWideEvent],
    ['getCurrentEvent', context.getCurrentEvent],
    ['getCorrelationId', context.getCorrelationId],
    ['enrich', context.enrich],
    ['extractClientContextCorrelationId', correlation.extractClientContextCorrelationId],
    ['extractCorrelationId', correlation.extractCorrelationId],
    ['shouldSample', sampling.shouldSample],
    ['parseLevel', levels.parseLevel],
    ['isLevelEnabled', levels.isLevelEnabled],
    ['deriveLevel', levels.deriveLevel],
    ['serializeError', serialize.serializeError],
    ['sanitize', serialize.sanitize],
    ['DEFAULT_REDACT_KEYS', redact.DEFAULT_REDACT_KEYS],
    ['REDACTED', redact.REDACTED],
    ['stdoutTransport', transport.stdoutTransport],
    ['createPinoInstance', pino.createPinoInstance],
    ['detectTrigger', detect.detectTrigger],
  ])('re-exporta %s', (name, original) => {
    expect((lib as Record<string, unknown>)[name]).toBe(original);
  });
});
