import { stdoutTransport } from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/transport';

describe('stdoutTransport', () => {
  afterEach(() => jest.restoreAllMocks());

  it('escreve a linha em stdout terminada por quebra de linha', () => {
    const write = jest.spyOn(process.stdout, 'write').mockImplementation(() => true);

    stdoutTransport('{"level":"info","message":"ok"}');

    expect(write).toHaveBeenCalledTimes(1);
    expect(write).toHaveBeenCalledWith('{"level":"info","message":"ok"}\n');
  });
});
