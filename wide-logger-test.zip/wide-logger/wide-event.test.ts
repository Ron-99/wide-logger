import { summarizeWideEvent, WideEvent } from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/wide-event';

const newEvent = (maxLogs = 10) => new WideEvent({ minLevel: 'info', maxLogs, includeStack: false });

describe('summarizeWideEvent', () => {
  it('usa método, path e status para HTTP', () => {
    expect(summarizeWideEvent({ http: { method: 'POST', path: '/x', status_code: 201 }, outcome: 'success' }, 5)).toBe(
      'POST /x 201 success 5ms',
    );
  });

  it('usa a rota quando não há path, e aceita só o path sem método', () => {
    expect(summarizeWideEvent({ http: { method: 'GET', route: 'GET /r' } }, 1)).toBe('GET GET /r 1ms');
    expect(summarizeWideEvent({ http: { path: '/p' } }, 1)).toBe('/p 1ms');
  });

  it('usa o trigger quando http não tem método nem path', () => {
    expect(summarizeWideEvent({ http: {}, trigger: { type: 'sqs', queue: 'fila' } }, 2)).toBe('sqs fila 2ms');
    expect(summarizeWideEvent({ trigger: { type: 'sns', topic: 'topico' } }, 2)).toBe('sns topico 2ms');
    expect(summarizeWideEvent({ trigger: { type: 'eventbridge', detail_type: 'Evt' } }, 2)).toBe('eventbridge Evt 2ms');
    expect(summarizeWideEvent({ trigger: { type: 'sqs' } }, 2)).toBe('sqs 2ms');
  });

  it('usa o service (ou "invocation") quando não há http nem trigger conhecido', () => {
    expect(summarizeWideEvent({ trigger: { type: 'unknown' }, service: 'svc' }, 3)).toBe('svc 3ms');
    expect(summarizeWideEvent({ trigger: {} }, 3)).toBe('invocation 3ms');
    expect(summarizeWideEvent({ http: 'x', trigger: 'y' }, 3)).toBe('invocation 3ms');
  });
});

describe('WideEvent', () => {
  it('set faz merge profundo, ignora undefined e copia objetos novos', () => {
    const nested = { b: 1 };
    const event = newEvent().set({ a: nested, x: 1 }).set({ a: { c: 2 }, x: undefined });
    nested.b = 99;

    expect(event.getFields()).toEqual({ a: { b: 1, c: 2 }, x: 1 });
  });

  it('set substitui valores que não são objetos simples', () => {
    const event = newEvent().set({ a: { b: 1 } }).set({ a: [1, 2] });
    expect(event.get('a')).toEqual([1, 2]);

    const nullProto = Object.assign(Object.create(null), { z: 1 });
    expect(newEvent().set({ n: nullProto }).get('n.z')).toBe(1);
  });

  it('add cria caminhos intermediários e ignora caminho vazio', () => {
    const event = newEvent().add('a.b.c', 1).add('a.x', 'texto').add('a.x.y', 2).add('', 'ignorado');
    expect(event.getFields()).toEqual({ a: { b: { c: 1 }, x: { y: 2 } } });
  });

  it('get devolve undefined ao passar por valores que não são objetos', () => {
    const event = newEvent().set({ a: { b: 'texto', n: null } });
    expect(event.get('a.b.c')).toBeUndefined();
    expect(event.get('a.n.c')).toBeUndefined();
    expect(event.get('inexistente')).toBeUndefined();
  });

  it('increment soma a partir de 0 ou do valor atual', () => {
    const event = newEvent().increment('db.queries').increment('db.queries', 2).add('txt', 'a').increment('txt');
    expect(event.get('db.queries')).toBe(3);
    expect(event.get('txt')).toBe(1);
  });

  it('setUser, setError, setLevel e escalate', () => {
    const event = newEvent().setUser({ id: 'u1' }).setError(new Error('x'), { etapa: 'bureau' }).setLevel('debug').escalate('warn');

    expect(event.get('user.id')).toBe('u1');
    expect(event.getError()).toEqual({ type: 'Error', message: 'x', etapa: 'bureau' });
    expect(event.getForcedLevel()).toBe('debug');
    expect(event.getLevelFloor()).toBe('warn');
    expect(event.escalate('info').getLevelFloor()).toBe('warn');
  });

  it('timer grava timings.<nome>_ms', () => {
    const event = newEvent();
    const ms = event.timer('motor')();
    expect(event.get('timings.motor_ms')).toBe(ms);
    expect(event.elapsedMs()).toBeGreaterThanOrEqual(0);
  });

  it('recordLog conta linhas emitidas e guarda as abaixo do nível, com ou sem data', () => {
    const event = newEvent(2);
    expect(event.getEmittedCounts()).toBeUndefined();

    expect(event.recordLog('info', 'a')).toBe(true);
    expect(event.recordLog('warn', 'b')).toBe(true);
    expect(event.recordLog('error', 'c')).toBe(true);
    expect(event.getEmittedCounts()).toEqual({ info: 1, warn: 1, error: 1 });
    expect(event.getLevelFloor()).toBe('error');

    expect(event.recordLog('debug', 'd1')).toBe(false);
    expect(event.recordLog('debug', 'd2', { x: 1 })).toBe(false);
    expect(event.recordLog('debug', 'd3', { y: 2 })).toBe(false);

    const buffered = event.getBufferedLogs();
    expect(buffered.map((l) => l.message)).toEqual(['d2', 'd3']);
    expect(buffered[0]).toMatchObject({ level: 'debug', message: 'd2', data: { x: 1 } });
    expect(buffered[0]).not.toHaveProperty('seq');
  });

  it('recordLog sem data não grava a chave data no buffer', () => {
    const event = newEvent();
    event.recordLog('debug', 'sem data');
    expect(event.getBufferedLogs()[0]).not.toHaveProperty('data');
  });
});
