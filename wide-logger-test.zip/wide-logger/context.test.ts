import {
  enrich,
  getCorrelationId,
  getCurrentEvent,
  runWithEvent,
} from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/context';
import { WideEvent } from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/wide-event';

const newEvent = () => new WideEvent({ minLevel: 'info', maxLogs: 10, includeStack: false });

describe('context', () => {
  it('fora de uma invocação não há evento e os atalhos não fazem nada', () => {
    expect(getCurrentEvent()).toBeUndefined();
    expect(getCorrelationId()).toBeUndefined();
    expect(() => enrich({ a: 1 })).not.toThrow();
  });

  it('dentro de runWithEvent expõe o evento, o correlation_id e enriquece', () => {
    const event = newEvent().set({ correlation_id: 'c-1' });

    const result = runWithEvent(event, () => {
      enrich({ user: { id: 'u1' } });
      return { current: getCurrentEvent(), correlationId: getCorrelationId() };
    });

    expect(result).toEqual({ current: event, correlationId: 'c-1' });
    expect(event.get('user.id')).toBe('u1');
  });
});
