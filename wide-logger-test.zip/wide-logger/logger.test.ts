import fs from 'fs';
import { createLogger, enrich, getCorrelationId, getCurrentEvent, type LambdaContext } from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger';
import { resetColdStart } from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/enrichers/lambda-context';
import { apiV2Event, captureLogger, fakeContext, sqsEvent } from './helpers';

beforeEach(() => resetColdStart());

describe('withWideEvent', () => {
  it('emite um wide event por invocação com sucesso', async () => {
    const { logger, records } = captureLogger();
    const handler = logger.withWideEvent(async () => {
      logger.getEvent().set({ user: { id: 'u1', tier: 'gold' } });
      return { statusCode: 200, body: 'ok' };
    });

    await expect(handler(apiV2Event, fakeContext())).resolves.toEqual({ statusCode: 200, body: 'ok' });

    const out = records();
    expect(out).toHaveLength(1);
    const ev = out[0]!;
    expect(ev).toMatchObject({
      level: 'info',
      log_type: 'wide_event',
      service: 'test-service',
      version: '1.0.0',
      environment: 'test',
      request_id: 'req-123',
      correlation_id: 'corr-1',
      outcome: 'success',
      user: { id: 'u1', tier: 'gold' },
      http: { method: 'POST', path: '/cotacoes', route: 'POST /cotacoes', status_code: 200 },
      trigger: { type: 'api_gateway_http' },
      lambda: { function_name: 'my-fn', memory_limit_mb: 512, cold_start: true, remaining_time_ms: 2900 },
      sampling: { rate: 1, reason: 'all' },
    });
    expect(typeof ev.duration_ms).toBe('number');
    expect(ev.logs).toBeUndefined();
    expect(ev.logs_emitted).toBeUndefined();
  });

  it('emite um wide event com erro e relança a exceção', async () => {
    const { logger, records } = captureLogger();
    const boom = Object.assign(new Error('cartão recusado'), { code: 'card_declined', retriable: false });
    const handler = logger.withWideEvent(async () => {
      throw boom;
    });

    await expect(handler({}, fakeContext())).rejects.toBe(boom);

    const out = records();
    expect(out).toHaveLength(1);
    expect(out[0]).toMatchObject({
      level: 'error',
      outcome: 'error',
      error: { type: 'Error', message: 'cartão recusado', code: 'card_declined', retriable: false },
      sampling: { reason: 'error' },
    });
    expect(out[0]!.error.stack).toContain('cartão recusado');
  });

  it('marca cold start apenas na primeira invocação', async () => {
    const { logger, records } = captureLogger();
    const handler = logger.withWideEvent(async () => 'ok');
    await handler({}, fakeContext());
    await handler({}, fakeContext());
    expect(records().map((r) => r.lambda.cold_start)).toEqual([true, false]);
  });

  it('deriva warn para respostas 4xx e error para 5xx', async () => {
    const { logger, records } = captureLogger();
    await logger.withWideEvent(async () => ({ statusCode: 404 }))(apiV2Event, fakeContext());
    await logger.withWideEvent(async () => ({ statusCode: 503 }))(apiV2Event, fakeContext());
    expect(records().map((r) => r.level)).toEqual(['warn', 'error']);
  });

  it('logger.error gera linha mas não copia a mensagem para o wide event', async () => {
    const { logger, records } = captureLogger();
    const handler = logger.withWideEvent(async () => {
      logger.error('falha ao publicar no SNS', new Error('SNS indisponível'));
      return 'ok';
    });

    await handler({}, fakeContext());

    const out = records();
    const line = out.find((r) => r.log_type === 'log')!;
    expect(line).toMatchObject({ level: 'error', correlation_id: 'req-123', message: 'falha ao publicar no SNS' });
    const ev = out.find((r) => r.log_type === 'wide_event')!;
    expect(ev).toMatchObject({ level: 'error', outcome: 'success', logs_emitted: { error: 1 } });
    expect(ev.error).toBeUndefined();
    expect(JSON.stringify(ev)).not.toContain('falha ao publicar no SNS');
  });

  it('atalhos add/set/timer/fail gravam no wide event', async () => {
    const { logger, records } = captureLogger();
    const handler = logger.withWideEvent(async () => {
      logger.add('bureau.status', 'ok');
      logger.set({ bureau: { from_cache: true } });
      const end = logger.timer('motor');
      end();
      logger.fail(new Error('SNS indisponível'), { retriable: true });
      return 'ok';
    });

    await handler({}, fakeContext());

    const ev = records().find((r) => r.log_type === 'wide_event')!;
    expect(ev).toMatchObject({
      level: 'error',
      outcome: 'success',
      bureau: { status: 'ok', from_cache: true },
      error: { type: 'Error', message: 'SNS indisponível', retriable: true },
    });
    expect(typeof ev.timings.motor_ms).toBe('number');
  });

  it('atalhos fora de withWideEvent não lançam erro', () => {
    const { logger, records } = captureLogger();
    expect(() => {
      logger.add('a.b', 1);
      logger.set({ a: 1 });
      logger.fail(new Error('x'));
    }).not.toThrow();
    expect(logger.timer('t')()).toBe(0);
    expect(records()).toHaveLength(0);
  });

  it('erro relançado com cause mantém a origem em error.cause', async () => {
    const { logger, records } = captureLogger();
    const handler = logger.withWideEvent(async () => {
      try {
        throw Object.assign(new Error('Request failed with status code 504'), { code: 'ECONNABORTED' });
      } catch (err) {
        throw new Error('Timeout na chamada do motor', { cause: err });
      }
    });

    await expect(handler({}, fakeContext())).rejects.toThrow('Timeout na chamada do motor');

    const ev = records().find((r) => r.log_type === 'wide_event')!;
    expect(ev.error).toMatchObject({
      message: 'Timeout na chamada do motor',
      cause: { message: 'Request failed with status code 504', code: 'ECONNABORTED' },
    });
  });

  it('logger.warn dentro da invocação escala o wide event para warn', async () => {
    const { logger, wide } = captureLogger();
    await logger.withWideEvent(async () => {
      logger.warn('fallback de tabela de preços');
      return 'ok';
    })({}, fakeContext());
    expect(wide()[0]!.level).toBe('warn');
  });

  it('setLevel força o nível final', async () => {
    const { logger, records } = captureLogger();
    await logger.withWideEvent(async () => {
      logger.getEvent().setLevel('error');
      return 'ok';
    })({}, fakeContext());
    expect(records()[0]!.level).toBe('error');
  });

  it('level=silent não emite nada, nem erros', async () => {
    const { logger, records } = captureLogger({ level: 'silent' });
    await expect(
      logger.withWideEvent(async () => {
        logger.error('x');
        throw new Error('x');
      })({}, fakeContext()),
    ).rejects.toThrow('x');
    expect(records()).toHaveLength(0);
  });

  it('getCurrentEvent/enrich funcionam em camadas profundas', async () => {
    const { logger, records } = captureLogger();
    const repository = async () => {
      enrich({ db: { table: 'apolices' } });
      getCurrentEvent()?.increment('db.queries');
      getCurrentEvent()?.increment('db.queries');
    };
    await logger.withWideEvent(async () => {
      await repository();
      return 'ok';
    })({}, fakeContext());
    expect(records()[0]!.db).toEqual({ table: 'apolices', queries: 2 });
  });

  it('timer grava latência em timings', async () => {
    const { logger, records } = captureLogger();
    await logger.withWideEvent(async () => {
      const end = logger.getEvent().timer('pricing');
      await new Promise((r) => setTimeout(r, 5));
      end();
      return 'ok';
    })({}, fakeContext());
    expect(records()[0]!.timings.pricing_ms).toBeGreaterThanOrEqual(0);
  });

  it('isola eventos de invocações concorrentes', async () => {
    const { logger, wide, immediate } = captureLogger();
    const handler = logger.withWideEvent(async (event: { id: string }) => {
      logger.getEvent().set({ order_id: event.id });
      await new Promise((r) => setTimeout(r, event.id === 'a' ? 10 : 1));
      logger.getEvent().add('order_id_check', event.id);
      logger.info('fim', { id: event.id });
      return 'ok';
    });
    await Promise.all([
      handler({ id: 'a' }, fakeContext({ awsRequestId: 'req-a' })),
      handler({ id: 'b' }, fakeContext({ awsRequestId: 'req-b' })),
    ]);
    for (const r of wide()) expect(r.order_id).toBe(r.order_id_check);
    for (const r of immediate()) expect(r.request_id).toBe(`req-${r.data.id}`);
  });

  it('redige chaves sensíveis (padrão + customizadas)', async () => {
    const { logger, records } = captureLogger({ redactKeys: ['numeroApolice'] });
    await logger.withWideEvent(async () => {
      logger.getEvent().set({ user: { id: 'u1', cpf: '123.456.789-00', senha: 'x' }, numero_apolice: 'P-1' });
      return 'ok';
    })({}, fakeContext());
    const ev = records()[0]!;
    expect(ev.user).toEqual({ id: 'u1', cpf: '[REDACTED]', senha: '[REDACTED]' });
    expect(ev.numero_apolice).toBe('[REDACTED]');
  });

  it('marca warn e conta falhas parciais de batch SQS', async () => {
    const { logger, records } = captureLogger();
    await logger.withWideEvent(async () => ({ batchItemFailures: [{ itemIdentifier: 'm2' }] }))(sqsEvent, fakeContext());
    const ev = records()[0]!;
    expect(ev.level).toBe('warn');
    expect(ev.trigger).toMatchObject({ type: 'sqs', queue: 'fila-sinistros', failed_count: 1, failed_ids: ['m2'] });
  });

  it('nunca derruba o handler se o transport falhar', async () => {
    const { logger } = captureLogger({
      transport: () => {
        throw new Error('stdout quebrado');
      },
    });
    await expect(
      logger.withWideEvent(async () => {
        logger.info('passou aqui');
        return 'ok';
      })({}, fakeContext()),
    ).resolves.toBe('ok');
  });

  it('trunca eventos maiores que maxEventBytes', async () => {
    const { logger, wide } = captureLogger({ maxEventBytes: 2000 });
    await logger
      .withWideEvent(async () => {
        for (let i = 0; i < 50; i++) logger.debug('x'.repeat(100));
        throw new Error('falhou');
      })({}, fakeContext())
      .catch(() => undefined);
    const ev = wide()[0]!;
    expect(ev.truncated).toBe(true);
    expect(ev.logs).toBeUndefined();
    expect(ev.service).toBe('test-service');
  });
});

describe('linhas imediatas dentro da invocação', () => {
  it('saem na hora, antes do wide event, com os IDs da invocação', async () => {
    const { logger, lines, records } = captureLogger();
    process.env._X_AMZN_TRACE_ID = 'Root=1-abc-def;Parent=1;Sampled=1';
    try {
      await logger.withWideEvent(async () => {
        logger.info('passou pela validação', { campos: 3 });
        expect(lines).toHaveLength(1); // já foi escrita antes do handler terminar
        logger.info('passou pelo cálculo');
        return { statusCode: 200 };
      })(apiV2Event, fakeContext());
    } finally {
      delete process.env._X_AMZN_TRACE_ID;
    }

    const out = records();
    expect(out.map((r) => r.log_type)).toEqual(['log', 'log', 'wide_event']);
    expect(out[0]).toMatchObject({
      level: 'info',
      log_type: 'log',
      service: 'test-service',
      request_id: 'req-123',
      trace_id: '1-abc-def',
      correlation_id: 'corr-1',
      message: 'passou pela validação',
      data: { campos: 3 },
    });
    expect(typeof out[0]!.elapsed_ms).toBe('number');
    // todas as linhas da invocação compartilham os mesmos IDs
    expect(new Set(out.map((r) => r.request_id))).toEqual(new Set(['req-123']));
    expect(new Set(out.map((r) => r.correlation_id))).toEqual(new Set(['corr-1']));
    // não duplica no wide event, só conta
    expect(out[2]!.logs).toBeUndefined();
    expect(out[2]!.logs_emitted).toEqual({ info: 2 });
  });

  it('respeitam o LOG_LEVEL', async () => {
    const { logger, immediate, wide } = captureLogger({ level: 'warn' });
    await logger.withWideEvent(async () => {
      logger.debug('d');
      logger.info('i');
      logger.warn('w');
      return 'ok';
    })({}, fakeContext());
    expect(immediate().map((r) => r.message)).toEqual(['w']);
    expect(wide()[0]!.logs_emitted).toEqual({ warn: 1 });
  });

  it('mensagens abaixo do nível entram no logs[] do wide event só se der erro', async () => {
    const { logger, wide, immediate } = captureLogger();
    await logger.withWideEvent(async () => {
      logger.debug('detalhe 1');
      return 'ok';
    })({}, fakeContext());
    await logger
      .withWideEvent(async () => {
        logger.debug('detalhe 2');
        logger.info('passo');
        throw new Error('falhou');
      })({}, fakeContext())
      .catch(() => undefined);

    const [ok, failed] = wide();
    expect(ok!.logs).toBeUndefined();
    expect(failed!.logs.map((l: any) => l.message)).toEqual(['detalhe 2']);
    expect(immediate().map((r) => r.message)).toEqual(['passo']);
  });

  it('flushDebugOnError=false não inclui debug em erros', async () => {
    const { logger, wide } = captureLogger({ flushDebugOnError: false });
    await logger
      .withWideEvent(async () => {
        logger.debug('detalhe');
        throw new Error('falhou');
      })({}, fakeContext())
      .catch(() => undefined);
    expect(wide()[0]!.logs).toBeUndefined();
  });

  it('limita o buffer de debug em maxLogs, mantendo os mais recentes', async () => {
    const { logger, wide } = captureLogger({ maxLogs: 2 });
    await logger
      .withWideEvent(async () => {
        for (let i = 0; i < 5; i++) logger.debug(`msg ${i}`);
        throw new Error('falhou');
      })({}, fakeContext())
      .catch(() => undefined);
    expect(wide()[0]!.logs.map((l: any) => l.message)).toEqual(['msg 3', 'msg 4']);
  });
});

describe('LOG_LEVEL não descarta wide events', () => {
  it('com level=warn, o wide event info continua sendo gravado', async () => {
    const { logger, wide } = captureLogger({ level: 'warn' });
    await logger.withWideEvent(async () => 'ok')({}, fakeContext());
    expect(wide()).toHaveLength(1);
    expect(wide()[0]!.level).toBe('info');
  });

  it('keep funciona mesmo com level=warn e sampleRate=0', async () => {
    const { logger, wide } = captureLogger({
      level: 'warn',
      sampleRate: 0,
      keep: (e) => (e.get('user.tier') === 'corporate' ? 'cliente_corporativo' : false),
    });
    const handler = logger.withWideEvent(async (tier: string) => {
      logger.getEvent().setUser({ tier });
      return 'ok';
    });
    await handler('gold', fakeContext());
    await handler('corporate', fakeContext());
    expect(wide().map((r) => r.sampling.reason)).toEqual(['cliente_corporativo']);
  });
});

describe('correlation_id', () => {
  afterEach(() => resetColdStart());

  it('usa o request_id quando o evento não traz um', async () => {
    const { logger, records } = captureLogger();
    await logger.withWideEvent(async () => 'ok')({}, fakeContext({ awsRequestId: 'req-xyz' }));
    expect(records()[0]!.correlation_id).toBe('req-xyz');
  });

  it('respeita correlationHeader customizado', async () => {
    const { logger, records } = captureLogger({ correlationHeader: 'x-request-id' });
    const event = { ...apiV2Event, headers: { 'X-Request-Id': 'abc-1' } };
    await logger.withWideEvent(async () => 'ok')(event, fakeContext());
    expect(records()[0]!.correlation_id).toBe('abc-1');
  });

  it('getCorrelationId devolve o ID para repassar a outros serviços', async () => {
    const { logger } = captureLogger();
    let seen: string | undefined;
    await logger.withWideEvent(async () => {
      seen = getCorrelationId();
      return 'ok';
    })(apiV2Event, fakeContext());
    expect(seen).toBe('corr-1');
    expect(getCorrelationId()).toBeUndefined();
  });
});

describe('logs fora de invocação', () => {
  it('emitem linha imediata respeitando o nível, sem IDs de invocação', () => {
    const { logger, records } = captureLogger({ level: 'info' });
    logger.debug('ignorado');
    logger.info('conexão inicializada', { pool: 5 });
    const out = records();
    expect(out).toHaveLength(1);
    expect(out[0]).toMatchObject({ level: 'info', log_type: 'log', message: 'conexão inicializada', data: { pool: 5 } });
    expect(out[0]!.request_id).toBeUndefined();
  });

  it('getEvent lança erro fora de withWideEvent', () => {
    const { logger } = captureLogger();
    expect(() => logger.getEvent()).toThrow(/fora de uma invocação/);
  });
});

describe('configuração por variáveis de ambiente', () => {
  it('lê LOG_LEVEL e LOG_SAMPLE_RATE', async () => {
    process.env.LOG_LEVEL = 'WARN';
    process.env.LOG_SAMPLE_RATE = '0';
    try {
      const { logger, records } = captureLogger({ level: undefined, sampleRate: undefined });
      expect(logger.level).toBe('warn');
      await logger.withWideEvent(async () => 'ok')({}, fakeContext());
      expect(records()).toHaveLength(0); // sampleRate 0 descarta o evento feliz
      await logger.withWideEvent(async () => ({ statusCode: 404 }))(apiV2Event, fakeContext());
      expect(records()[0]).toMatchObject({ level: 'warn', sampling: { rate: 0, reason: 'warn' } });
    } finally {
      delete process.env.LOG_LEVEL;
      delete process.env.LOG_SAMPLE_RATE;
    }
  });
});

describe('correlation_id via ClientContext', () => {
  it('usa Custom.correlationId do ClientContext quando o evento não traz o ID', async () => {
    const { logger, wide } = captureLogger();
    await logger.withWideEvent(async () => 'ok')(
      { foo: 1 },
      fakeContext({ clientContext: { Custom: { correlationId: 'corr-ctx' } } }),
    );
    expect(wide()[0]!.correlation_id).toBe('corr-ctx');
  });

  it('o ID do evento tem prioridade sobre o ClientContext', async () => {
    const { logger, wide } = captureLogger();
    await logger.withWideEvent(async () => 'ok')(
      apiV2Event,
      fakeContext({ clientContext: { Custom: { correlationId: 'corr-ctx' } } }),
    );
    expect(wide()[0]!.correlation_id).toBe('corr-1');
  });
});

describe('timeout da Lambda', () => {
  it('grava o wide event com outcome timeout antes de o tempo acabar', async () => {
    const { logger, wide } = captureLogger({ timeoutMarginMs: 50 });
    let release!: () => void;
    const handler = logger.withWideEvent(async () => {
      logger.getEvent().set({ etapa: 'chamando motor' });
      await new Promise<void>((resolve) => {
        release = resolve;
      });
      return 'ok';
    });

    const running = handler({}, fakeContext({ getRemainingTimeInMillis: () => 100 }));
    await new Promise((r) => setTimeout(r, 120));

    expect(wide()).toHaveLength(1);
    expect(wide()[0]).toMatchObject({
      level: 'error',
      outcome: 'timeout',
      etapa: 'chamando motor',
      error: { type: 'LambdaTimeoutError' },
      sampling: { reason: 'error' },
    });

    release();
    await running;
    expect(wide()).toHaveLength(1);
  });

  it('não grava evento de timeout quando a invocação termina a tempo', async () => {
    const { logger, wide } = captureLogger({ timeoutMarginMs: 50 });
    await logger.withWideEvent(async () => 'ok')({}, fakeContext({ getRemainingTimeInMillis: () => 100 }));
    await new Promise((r) => setTimeout(r, 80));
    expect(wide()).toHaveLength(1);
    expect(wide()[0]!.outcome).toBe('success');
  });

  it('timeoutMarginMs 0 desliga a proteção', async () => {
    const { logger, wide } = captureLogger({ timeoutMarginMs: 0 });
    let release!: () => void;
    const running = logger.withWideEvent(
      () => new Promise<string>((resolve) => { release = () => resolve('ok'); }),
    )({}, fakeContext({ getRemainingTimeInMillis: () => 60 }));
    await new Promise((r) => setTimeout(r, 80));
    expect(wide()).toHaveLength(0);
    release();
    await running;
    expect(wide()[0]!.outcome).toBe('success');
  });
});

describe('configuração padrão e por ambiente', () => {
  const ENV_KEYS = [
    'SERVICE_NAME',
    'SERVICE_VERSION',
    'AWS_LAMBDA_FUNCTION_NAME',
    'AWS_LAMBDA_FUNCTION_VERSION',
    'ENVIRONMENT',
    'STAGE',
    'NODE_ENV',
    'LOG_LEVEL',
    'AWS_LAMBDA_LOG_LEVEL',
    'LOG_SAMPLE_RATE',
  ];
  let saved: Record<string, string | undefined>;

  beforeEach(() => {
    saved = Object.fromEntries(ENV_KEYS.map((k) => [k, process.env[k]]));
    ENV_KEYS.forEach((k) => delete process.env[k]);
  });

  afterEach(() => {
    ENV_KEYS.forEach((k) => {
      if (saved[k] === undefined) delete process.env[k];
      else process.env[k] = saved[k];
    });
    jest.restoreAllMocks();
  });

  it('createLogger() sem opções nem ambiente usa os defaults', () => {
    const write = jest.spyOn(fs, 'writeSync').mockImplementation((_fd, data) => String(data).length);
    const logger = createLogger();
    logger.info('oi');

    expect(logger.level).toBe('info');
    const line = JSON.parse(String(write.mock.calls[0]![1]));
    expect(line).toMatchObject({ service: 'unknown', 'service.name': 'unknown', message: 'oi' });
    expect(line.version).toBeUndefined();
    expect(line.environment).toBeUndefined();
  });

  it('lê SERVICE_NAME, SERVICE_VERSION, ENVIRONMENT e LOG_LEVEL', () => {
    Object.assign(process.env, { SERVICE_NAME: 'svc', SERVICE_VERSION: '2', ENVIRONMENT: 'hml', LOG_LEVEL: 'warn' });
    const { logger, records } = captureLogger({ service: undefined, version: undefined, environment: undefined, level: undefined });
    logger.warn('x');
    expect(logger.level).toBe('warn');
    expect(records()[0]).toMatchObject({ service: 'svc', version: '2', environment: 'hml' });
  });

  it('cai para as variáveis da Lambda, STAGE e AWS_LAMBDA_LOG_LEVEL', () => {
    Object.assign(process.env, {
      AWS_LAMBDA_FUNCTION_NAME: 'fn',
      AWS_LAMBDA_FUNCTION_VERSION: '7',
      STAGE: 'dev',
      AWS_LAMBDA_LOG_LEVEL: 'ERROR',
    });
    const { logger, records } = captureLogger({ service: undefined, version: undefined, environment: undefined, level: undefined });
    logger.error('x');
    expect(logger.level).toBe('error');
    expect(records()[0]).toMatchObject({ service: 'fn', version: '7', environment: 'dev' });
  });

  it('usa NODE_ENV como último recurso de ambiente', () => {
    process.env.NODE_ENV = 'test-env';
    const { logger, records } = captureLogger({ environment: undefined });
    logger.info('x');
    expect(records()[0]!.environment).toBe('test-env');
  });

  it.each([
    ['', 1],
    ['0', 0],
    ['abc', 1],
    ['5', 1],
  ])('LOG_SAMPLE_RATE=%p resulta em rate %p', async (value, rate) => {
    process.env.LOG_SAMPLE_RATE = value;
    const { logger, records } = captureLogger({ sampleRate: undefined, random: () => 0.5 });
    await logger.withWideEvent(async () => 'ok')({}, fakeContext());
    if (rate === 0) expect(records()).toHaveLength(0);
    else expect(records()[0]!.sampling).toEqual({ rate, reason: 'all' });
  });

  it('sampleRate NaN nas opções vira 1 e valores fora da faixa são limitados', async () => {
    const nan = captureLogger({ sampleRate: Number.NaN });
    await nan.logger.withWideEvent(async () => 'ok')({}, fakeContext());
    expect(nan.records()[0]!.sampling.rate).toBe(1);

    const negativo = captureLogger({ sampleRate: -1 });
    await negativo.logger.withWideEvent(async () => 'ok')({}, fakeContext());
    expect(negativo.records()).toHaveLength(0);
  });
});

describe('opções de saída', () => {
  it('includeStack=false, redactDefaults=false e maxStringLength', async () => {
    const { logger, wide } = captureLogger({ includeStack: false, redactDefaults: false, maxStringLength: 12 });
    await expect(
      logger.withWideEvent(async () => {
        logger.set({ senha: 'aberta', texto: 'x'.repeat(20) });
        throw new Error('falhou');
      })({}, fakeContext()),
    ).rejects.toThrow('falhou');

    const ev = wide()[0]!;
    expect(ev.error.stack).toBeUndefined();
    expect(ev.senha).toBe('aberta');
    expect(ev.texto).toBe(`${'x'.repeat(12)}…[truncated 8 chars]`);
  });

  it('linha com message que não é string sai sem message', () => {
    const { logger, records } = captureLogger();
    logger.info(123 as unknown as string);
    expect(records()[0]!.message).toBeUndefined();
  });

  it('staticFields entram no wide event', async () => {
    const { logger, wide } = captureLogger({ staticFields: { squad: 'blaze' } });
    await logger.withWideEvent(async () => 'ok')({}, fakeContext());
    expect(wide()[0]!.squad).toBe('blaze');
  });

  it('traceContext adiciona dt.trace_id/dt.span_id e é ignorado se falhar ou não retornar nada', () => {
    const ok = captureLogger({ traceContext: () => ({ trace_id: 't1', span_id: 's1' }) });
    ok.logger.info('x');
    expect(ok.records()[0]).toMatchObject({ 'dt.trace_id': 't1', 'dt.span_id': 's1' });

    const vazio = captureLogger({ traceContext: () => undefined });
    vazio.logger.info('x');
    expect(vazio.records()[0]!['dt.trace_id']).toBeUndefined();

    const quebrado = captureLogger({
      traceContext: () => {
        throw new Error('otel');
      },
    });
    quebrado.logger.info('x');
    expect(quebrado.records()[0]!['dt.trace_id']).toBeUndefined();
  });

  it('evento que continua grande sem os logs fica só com o núcleo e sem stack', async () => {
    const { logger, wide } = captureLogger({ maxEventBytes: 600, level: 'info' });
    await expect(
      logger.withWideEvent(async () => {
        logger.debug('debug guardado');
        logger.set({ grande: 'x'.repeat(2000) });
        throw new Error('falhou');
      })({}, fakeContext()),
    ).rejects.toThrow();

    const ev = wide()[0]!;
    expect(ev.truncated).toBe(true);
    expect(ev.grande).toBeUndefined();
    expect(ev.logs).toBeUndefined();
    expect(ev.error).toMatchObject({ type: 'Error', message: 'falhou' });
    expect(ev.error.stack).toBeUndefined();
  });

  it('evento que cabe sem os logs de debug descarta só os logs', async () => {
    const { logger, wide } = captureLogger({ maxEventBytes: 1500, includeStack: false });
    await expect(
      logger.withWideEvent(async () => {
        for (let i = 0; i < 20; i++) logger.debug(`debug ${i}`, { detalhe: 'y'.repeat(50) });
        logger.set({ pedido: 'p-1' });
        throw new Error('falhou');
      })({}, fakeContext()),
    ).rejects.toThrow();

    const ev = wide()[0]!;
    expect(ev).toMatchObject({ truncated: true, pedido: 'p-1', outcome: 'error' });
    expect(ev.logs).toBeUndefined();
  });

  it('evento grande sem erro também é reduzido ao núcleo', async () => {
    const { logger, wide } = captureLogger({ maxEventBytes: 600 });
    await logger.withWideEvent(async () => {
      logger.set({ grande: 'x'.repeat(2000) });
    })({}, fakeContext());

    expect(wide()[0]).toMatchObject({ truncated: true, outcome: 'success' });
    expect(wide()[0]!.error).toBeUndefined();
  });
});

describe('withWideEvent - casos de borda', () => {
  it('autoEnrich=false não detecta o trigger nem lê o resultado', async () => {
    const { logger, wide } = captureLogger({ autoEnrich: false });
    await logger.withWideEvent(async () => ({ statusCode: 500 }))(apiV2Event, fakeContext());

    const ev = wide()[0]!;
    expect(ev.trigger).toBeUndefined();
    expect(ev.http).toBeUndefined();
    expect(ev.level).toBe('info');
  });

  it('funciona sem context', async () => {
    const { logger, wide } = captureLogger();
    await logger.withWideEvent(async () => 'ok')({}, undefined as unknown as LambdaContext);

    expect(wide()[0]).toMatchObject({ outcome: 'success' });
    expect(wide()[0]!.correlation_id).toBeUndefined();
  });

  it('ignora getRemainingTimeInMillis ausente, não numérico ou que lança erro', async () => {
    const contexts = [
      fakeContext({ getRemainingTimeInMillis: undefined }),
      fakeContext({ getRemainingTimeInMillis: () => Number.NaN }),
      fakeContext({
        getRemainingTimeInMillis: () => {
          throw new Error('x');
        },
      }),
    ];
    for (const ctx of contexts) {
      const { logger, wide } = captureLogger();
      await logger.withWideEvent(async () => 'ok')({}, ctx);
      expect(wide()).toHaveLength(1);
    }
  });

  it('não quebra quando o timer não tem unref', async () => {
    const realSetTimeout = global.setTimeout;
    const spy = jest
      .spyOn(global, 'setTimeout')
      .mockImplementation(((fn: () => void, ms?: number) => {
        const t = realSetTimeout(fn, ms);
        clearTimeout(t);
        return {} as NodeJS.Timeout;
      }) as typeof setTimeout);
    try {
      const { logger, wide } = captureLogger();
      await logger.withWideEvent(async () => 'ok')({}, fakeContext());
      expect(wide()).toHaveLength(1);
    } finally {
      spy.mockRestore();
    }
  });

  it('ignora falhas ao montar os campos de início e de fim da Lambda', async () => {
    const ctx = fakeContext();
    Object.defineProperty(ctx, 'awsRequestId', {
      get: () => {
        throw new Error('quebrado');
      },
    });
    const memory = jest.spyOn(process, 'memoryUsage').mockImplementation(() => {
      throw new Error('sem memória');
    });
    try {
      const { logger, wide } = captureLogger();
      await logger.withWideEvent(async () => 'ok')({}, ctx);
      expect(wide()[0]).toMatchObject({ outcome: 'success' });
    } finally {
      memory.mockRestore();
    }
  });

  it('ignora falhas ao ler o resultado do handler', async () => {
    const { logger, wide } = captureLogger();
    const result = {
      get statusCode(): number {
        throw new Error('quebrado');
      },
    };
    await logger.withWideEvent(async () => result)(apiV2Event, fakeContext());
    expect(wide()[0]).toMatchObject({ outcome: 'success' });
  });
});
