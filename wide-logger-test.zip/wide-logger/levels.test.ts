import {
  deriveLevel,
  isLevelEnabled,
  maxLevel,
  parseLevel,
} from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/levels';

describe('parseLevel', () => {
  it('aceita aliases sem diferença de maiúsculas e espaços', () => {
    expect(parseLevel('DEBUG', 'info')).toBe('debug');
    expect(parseLevel('TRACE', 'info')).toBe('debug');
    expect(parseLevel(' warning ', 'info')).toBe('warn');
    expect(parseLevel('FATAL', 'info')).toBe('error');
    expect(parseLevel('off', 'info')).toBe('silent');
  });

  it('cai no fallback para valor vazio, ausente ou desconhecido', () => {
    expect(parseLevel('lixo', 'info')).toBe('info');
    expect(parseLevel('', 'warn')).toBe('warn');
    expect(parseLevel(undefined, 'error')).toBe('error');
    expect(parseLevel(null, 'debug')).toBe('debug');
  });
});

describe('isLevelEnabled / maxLevel', () => {
  it('compara níveis', () => {
    expect(isLevelEnabled('warn', 'info')).toBe(true);
    expect(isLevelEnabled('debug', 'info')).toBe(false);
    expect(isLevelEnabled('error', 'silent')).toBe(false);
    expect(maxLevel('info', 'warn')).toBe('warn');
    expect(maxLevel('error', 'warn')).toBe('error');
  });
});

describe('deriveLevel', () => {
  const base = { floor: 'info' as const, hasError: false, durationMs: 10, slowThresholdMs: 1000 };

  it('usa o nível forçado', () => {
    expect(deriveLevel({ ...base, forced: 'debug', hasError: true })).toBe('debug');
  });

  it('error para erro ou 5xx, warn para 4xx ou lentidão', () => {
    expect(deriveLevel({ ...base, hasError: true })).toBe('error');
    expect(deriveLevel({ ...base, statusCode: 503 })).toBe('error');
    expect(deriveLevel({ ...base, statusCode: 404 })).toBe('warn');
    expect(deriveLevel({ ...base, statusCode: 200 })).toBe('info');
    expect(deriveLevel({ ...base, durationMs: 2000 })).toBe('warn');
  });

  it('respeita o piso', () => {
    expect(deriveLevel({ ...base, floor: 'warn' })).toBe('warn');
  });
});
