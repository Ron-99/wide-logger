import { PinoInstrumentation as OriginalPinoInstrumentation } from '@opentelemetry/instrumentation-pino';
import {
  createPinoInstrumentation,
  DYNATRACE_LOG_KEYS,
  PinoInstrumentation,
} from '../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/otel';

describe('createPinoInstrumentation', () => {
  it('sem argumentos usa as chaves dt.* e desliga o envio via OTLP', () => {
    const inst = createPinoInstrumentation();
    try {
      expect(inst).toBeInstanceOf(OriginalPinoInstrumentation);
      expect(inst.getConfig()).toMatchObject({ logKeys: DYNATRACE_LOG_KEYS, disableLogSending: true });
    } finally {
      inst.disable();
    }
  });

  it('respeita logKeys customizadas', () => {
    const logKeys = { traceId: 'meu.trace', spanId: 'meu.span', traceFlags: 'minhas.flags' };
    const inst = createPinoInstrumentation({ enabled: false, logKeys });

    expect(inst.getConfig()).toMatchObject({ logKeys, disableLogSending: true });
  });

  it('permite religar o envio via OTLP', () => {
    const inst = createPinoInstrumentation({ enabled: false, disableLogSending: false });

    expect(inst.getConfig()).toMatchObject({ logKeys: DYNATRACE_LOG_KEYS, disableLogSending: false });
  });
});

describe('re-export', () => {
  it('expõe a PinoInstrumentation original', () => {
    expect(PinoInstrumentation).toBe(OriginalPinoInstrumentation);
  });
});
