import { detectTrigger } from '../../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/enrichers/detect';
import { apiV1Event, apiV2Event, eventBridgeEvent, snsEvent, sqsEvent } from '../helpers';

describe('detectTrigger', () => {
  it('API Gateway HTTP API (v2)', () => {
    const t = detectTrigger(apiV2Event);
    expect(t.type).toBe('api_gateway_http');
    expect(t.start(apiV2Event)).toMatchObject({
      http: { method: 'POST', path: '/cotacoes', route: 'POST /cotacoes', source_ip: '10.0.0.1', api_request_id: 'apigw-1' },
    });
    expect(t.result?.({ statusCode: 201 })).toEqual({ http: { status_code: 201 } });
  });

  it('API Gateway REST (v1)', () => {
    const t = detectTrigger(apiV1Event);
    expect(t.type).toBe('api_gateway_rest');
    expect(t.start(apiV1Event)).toMatchObject({
      http: { method: 'GET', path: '/apolices/42', route: '/apolices/{id}', stage: 'prd', source_ip: '10.0.0.2', user_agent: 'jest' },
    });
  });

  it('SQS', () => {
    const t = detectTrigger(sqsEvent);
    expect(t.type).toBe('sqs');
    expect(t.start(sqsEvent)).toEqual({
      trigger: { type: 'sqs', queue: 'fila-sinistros', record_count: 2, message_ids: ['m1', 'm2'], max_receive_count: 3 },
    });
    expect(t.result).toBeDefined();
  });

  it('SNS', () => {
    const t = detectTrigger(snsEvent);
    expect(t.type).toBe('sns');
    expect(t.start(snsEvent)).toEqual({
      trigger: { type: 'sns', topic: 'topico-apolice', record_count: 1, message_ids: ['sns-1'] },
    });
    expect(t.result).toBeUndefined();
  });

  it('EventBridge', () => {
    const t = detectTrigger(eventBridgeEvent);
    expect(t.type).toBe('eventbridge');
    expect(t.start(eventBridgeEvent)).toMatchObject({
      trigger: { type: 'eventbridge', source: 'mapfre.apolices', detail_type: 'ApoliceEmitida', event_id: 'eb-1' },
    });
  });

  it('desconhecido', () => {
    expect(detectTrigger({ foo: 1 }).type).toBe('unknown');
    expect(detectTrigger(null).type).toBe('unknown');
    expect(detectTrigger('texto').type).toBe('unknown');
    expect(detectTrigger({ foo: 1 }).start({})).toEqual({ trigger: { type: 'unknown' } });
  });
});
