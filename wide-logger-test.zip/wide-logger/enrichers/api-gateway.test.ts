import {
  apiGatewayResultFields,
  enrichApiGatewayV1,
  enrichApiGatewayV2,
  isApiGatewayV1,
  isApiGatewayV2,
} from '../../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/enrichers/api-gateway';

describe('isApiGatewayV2', () => {
  it('reconhece payload v2 com requestContext.http', () => {
    expect(isApiGatewayV2({ version: '2.0', requestContext: { http: { method: 'GET' } } })).toBe(true);
  });

  it('rejeita versão diferente de 2.0', () => {
    expect(isApiGatewayV2({ version: '1.0', requestContext: { http: {} } })).toBe(false);
  });

  it('rejeita v2 sem requestContext', () => {
    expect(isApiGatewayV2({ version: '2.0' })).toBe(false);
  });

  it('rejeita v2 sem requestContext.http', () => {
    expect(isApiGatewayV2({ version: '2.0', requestContext: {} })).toBe(false);
  });
});

describe('isApiGatewayV1', () => {
  it('reconhece payload v1', () => {
    expect(isApiGatewayV1({ httpMethod: 'POST', requestContext: {} })).toBe(true);
  });

  it('rejeita sem httpMethod', () => {
    expect(isApiGatewayV1({ requestContext: {} })).toBe(false);
  });

  it('rejeita sem requestContext', () => {
    expect(isApiGatewayV1({ httpMethod: 'POST' })).toBe(false);
  });
});

describe('enrichApiGatewayV2', () => {
  it('usa os campos do requestContext quando presentes', () => {
    const out = enrichApiGatewayV2({
      rawPath: '/cotacoes',
      routeKey: 'POST /cotacoes',
      headers: { 'user-agent': 'header-agent' },
      requestContext: {
        stage: 'dev',
        requestId: 'req-1',
        http: { method: 'POST', path: '/ignorado', sourceIp: '1.2.3.4', userAgent: 'rc-agent' },
      },
    });

    expect(out).toEqual({
      trigger: { type: 'api_gateway_http' },
      http: {
        method: 'POST',
        path: '/cotacoes',
        route: 'POST /cotacoes',
        stage: 'dev',
        source_ip: '1.2.3.4',
        user_agent: 'rc-agent',
        api_request_id: 'req-1',
      },
    });
  });

  it('cai para requestContext.http.path e user-agent do header (case-insensitive)', () => {
    const out = enrichApiGatewayV2({
      headers: { Accept: 'json', 'User-Agent': 'header-agent' },
      requestContext: { http: { method: 'GET', path: '/rc-path' } },
    });

    expect(out.http).toMatchObject({ path: '/rc-path', user_agent: 'header-agent' });
  });

  it('não quebra sem requestContext nem headers', () => {
    const out = enrichApiGatewayV2({});

    expect(out).toEqual({
      trigger: { type: 'api_gateway_http' },
      http: {
        method: undefined,
        path: undefined,
        route: undefined,
        stage: undefined,
        source_ip: undefined,
        user_agent: undefined,
        api_request_id: undefined,
      },
    });
  });

  it('ignora header user-agent que não é string e headers sem user-agent', () => {
    expect(enrichApiGatewayV2({ headers: { 'user-agent': ['a', 'b'] } }).http).toMatchObject({
      user_agent: undefined,
    });
    expect(enrichApiGatewayV2({ headers: { accept: 'json' } }).http).toMatchObject({ user_agent: undefined });
  });
});

describe('enrichApiGatewayV1', () => {
  it('usa os campos do requestContext.identity quando presentes', () => {
    const out = enrichApiGatewayV1({
      httpMethod: 'GET',
      path: '/apolices/1',
      resource: '/apolices/{id}',
      headers: { 'user-agent': 'header-agent' },
      requestContext: { stage: 'prd', requestId: 'req-2', identity: { sourceIp: '5.6.7.8', userAgent: 'id-agent' } },
    });

    expect(out).toEqual({
      trigger: { type: 'api_gateway_rest' },
      http: {
        method: 'GET',
        path: '/apolices/1',
        route: '/apolices/{id}',
        stage: 'prd',
        source_ip: '5.6.7.8',
        user_agent: 'id-agent',
        api_request_id: 'req-2',
      },
    });
  });

  it('cai para o user-agent do header quando identity não tem', () => {
    const out = enrichApiGatewayV1({ httpMethod: 'GET', headers: { 'USER-AGENT': 'header-agent' }, requestContext: {} });

    expect(out.http).toMatchObject({ source_ip: undefined, user_agent: 'header-agent' });
  });

  it('não quebra sem requestContext nem headers', () => {
    const out = enrichApiGatewayV1({ httpMethod: 'GET' });

    expect(out.http).toMatchObject({ method: 'GET', stage: undefined, source_ip: undefined, user_agent: undefined });
  });
});

describe('apiGatewayResultFields', () => {
  it('usa o statusCode do retorno', () => {
    expect(apiGatewayResultFields({ statusCode: 404 })).toEqual({ http: { status_code: 404 } });
  });

  it.each([undefined, null, 'texto', { body: 'ok' }, { statusCode: '500' }])(
    'assume 200 quando não há statusCode numérico (%p)',
    (result) => {
      expect(apiGatewayResultFields(result)).toEqual({ http: { status_code: 200 } });
    },
  );
});
