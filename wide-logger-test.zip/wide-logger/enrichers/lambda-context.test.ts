import {
  consumeColdStart,
  lambdaEndFields,
  lambdaStartFields,
  parseTraceId,
  resetColdStart,
} from '../../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/enrichers/lambda-context';
import type { LambdaContext } from '../../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/types';
import { fakeContext } from '../helpers';

const ENV_KEYS = [
  '_X_AMZN_TRACE_ID',
  'AWS_REGION',
  'AWS_LAMBDA_FUNCTION_NAME',
  'AWS_LAMBDA_FUNCTION_VERSION',
  'AWS_LAMBDA_FUNCTION_MEMORY_SIZE',
  'AWS_LAMBDA_INITIALIZATION_TYPE',
] as const;

let savedEnv: Record<string, string | undefined>;

beforeEach(() => {
  savedEnv = Object.fromEntries(ENV_KEYS.map((k) => [k, process.env[k]]));
  ENV_KEYS.forEach((k) => delete process.env[k]);
  resetColdStart();
});

afterEach(() => {
  ENV_KEYS.forEach((k) => {
    if (savedEnv[k] === undefined) delete process.env[k];
    else process.env[k] = savedEnv[k];
  });
  jest.restoreAllMocks();
});

describe('consumeColdStart', () => {
  it('retorna true só na primeira chamada', () => {
    expect(consumeColdStart()).toBe(true);
    expect(consumeColdStart()).toBe(false);
  });

  it('retorna false com provisioned concurrency', () => {
    process.env.AWS_LAMBDA_INITIALIZATION_TYPE = 'provisioned-concurrency';
    expect(consumeColdStart()).toBe(false);
  });
});

describe('parseTraceId', () => {
  it('extrai o Root do header X-Ray', () => {
    expect(parseTraceId('Root=1-abc-def;Parent=123;Sampled=1')).toBe('1-abc-def');
  });

  it('retorna undefined para header vazio ou ausente', () => {
    expect(parseTraceId(undefined)).toBeUndefined();
    expect(parseTraceId('')).toBeUndefined();
  });

  it('retorna undefined quando o header não tem Root', () => {
    expect(parseTraceId('Parent=123;Sampled=1')).toBeUndefined();
  });
});

describe('lambdaStartFields', () => {
  it('usa os campos do context', () => {
    process.env._X_AMZN_TRACE_ID = 'Root=1-abc-def;Sampled=1';
    process.env.AWS_REGION = 'sa-east-1';
    process.env.AWS_LAMBDA_FUNCTION_NAME = 'env-fn';

    expect(lambdaStartFields(fakeContext(), true)).toEqual({
      request_id: 'req-123',
      trace_id: '1-abc-def',
      region: 'sa-east-1',
      lambda: {
        function_name: 'my-fn',
        function_version: '$LATEST',
        memory_limit_mb: 512,
        log_stream: '2026/10/22/[$LATEST]abc',
        cold_start: true,
      },
    });
  });

  it('cai para as variáveis de ambiente sem context', () => {
    process.env.AWS_LAMBDA_FUNCTION_NAME = 'env-fn';
    process.env.AWS_LAMBDA_FUNCTION_VERSION = '7';
    process.env.AWS_LAMBDA_FUNCTION_MEMORY_SIZE = '1024';

    expect(lambdaStartFields(undefined, false)).toEqual({
      request_id: undefined,
      trace_id: undefined,
      region: undefined,
      lambda: {
        function_name: 'env-fn',
        function_version: '7',
        memory_limit_mb: 1024,
        log_stream: undefined,
        cold_start: false,
      },
    });
  });

  it('deixa memory_limit_mb undefined quando não há valor numérico', () => {
    expect((lambdaStartFields(undefined, false).lambda as Record<string, unknown>).memory_limit_mb).toBeUndefined();

    const ctx = fakeContext({ memoryLimitInMB: 'abc' });
    expect((lambdaStartFields(ctx, false).lambda as Record<string, unknown>).memory_limit_mb).toBeUndefined();
  });
});

describe('lambdaEndFields', () => {
  beforeEach(() => {
    jest.spyOn(process, 'memoryUsage').mockReturnValue({ rss: 100 * 1024 * 1024 } as NodeJS.MemoryUsage);
  });

  it('lê o tempo restante e a memória usada', () => {
    expect(lambdaEndFields(fakeContext())).toEqual({ lambda: { remaining_time_ms: 2900, memory_used_mb: 100 } });
  });

  it('não quebra sem context', () => {
    expect(lambdaEndFields(undefined)).toEqual({ lambda: { remaining_time_ms: undefined, memory_used_mb: 100 } });
  });

  it('não quebra quando o context não tem getRemainingTimeInMillis', () => {
    const ctx = fakeContext({ getRemainingTimeInMillis: undefined });
    expect(lambdaEndFields(ctx).lambda).toMatchObject({ remaining_time_ms: undefined });
  });

  it('não quebra quando getRemainingTimeInMillis lança erro', () => {
    const ctx: LambdaContext = fakeContext({
      getRemainingTimeInMillis: () => {
        throw new Error('falhou');
      },
    });
    expect(lambdaEndFields(ctx).lambda).toMatchObject({ remaining_time_ms: undefined });
  });
});
