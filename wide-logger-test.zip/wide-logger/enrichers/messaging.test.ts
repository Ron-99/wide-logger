import {
  batchResultFields,
  enrichEventBridge,
  enrichSns,
  enrichSqs,
  isEventBridge,
  isSns,
  isSqs,
} from '../../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/enrichers/messaging';
import { eventBridgeEvent, snsEvent, sqsEvent } from '../helpers';

describe('detecção', () => {
  it('isSqs / isSns olham o primeiro record', () => {
    expect(isSqs(sqsEvent)).toBe(true);
    expect(isSns(snsEvent)).toBe(true);
    expect(isSqs(snsEvent)).toBe(false);
    expect(isSns(sqsEvent)).toBe(false);
  });

  it('não reconhecem eventos sem Records ou com Records vazio', () => {
    expect(isSqs({})).toBe(false);
    expect(isSns({ Records: 'x' })).toBe(false);
    expect(isSqs({ Records: [] })).toBe(false);
  });

  it('isEventBridge exige detail-type e source em texto', () => {
    expect(isEventBridge(eventBridgeEvent)).toBe(true);
    expect(isEventBridge({ 'detail-type': 'X' })).toBe(false);
    expect(isEventBridge({ source: 'x', 'detail-type': 1 })).toBe(false);
  });
});

describe('enrichSqs', () => {
  it('usa o maior ApproximateReceiveCount e o nome da fila', () => {
    expect(enrichSqs(sqsEvent)).toEqual({
      trigger: { type: 'sqs', queue: 'fila-sinistros', record_count: 2, message_ids: ['m1', 'm2'], max_receive_count: 3 },
    });
  });

  it('não quebra com records sem attributes nem ARN', () => {
    expect(enrichSqs({ Records: [{ messageId: 'm1' }] })).toEqual({
      trigger: { type: 'sqs', queue: undefined, record_count: 1, message_ids: ['m1'], max_receive_count: undefined },
    });
  });

  it('não quebra com Records vazio', () => {
    expect(enrichSqs({ Records: [] })).toEqual({
      trigger: { type: 'sqs', queue: undefined, record_count: 0, message_ids: [], max_receive_count: undefined },
    });
  });

  it('limita message_ids a 10', () => {
    const Records = Array.from({ length: 12 }, (_, i) => ({ messageId: `m${i}` }));
    const trigger = enrichSqs({ Records }).trigger as Record<string, unknown>;
    expect(trigger.record_count).toBe(12);
    expect(trigger.message_ids).toHaveLength(10);
  });
});

describe('enrichSns', () => {
  it('usa o nome do tópico e os MessageIds', () => {
    expect(enrichSns(snsEvent)).toEqual({
      trigger: { type: 'sns', topic: 'topico-apolice', record_count: 1, message_ids: ['sns-1'] },
    });
  });

  it('não quebra com records sem Sns ou Records vazio', () => {
    expect(enrichSns({ Records: [{}] })).toEqual({
      trigger: { type: 'sns', topic: undefined, record_count: 1, message_ids: [undefined] },
    });
    expect(enrichSns({ Records: [] })).toEqual({
      trigger: { type: 'sns', topic: undefined, record_count: 0, message_ids: [] },
    });
  });
});

describe('enrichEventBridge', () => {
  it('lê source, detail-type, id, time e quantidade de resources', () => {
    expect(enrichEventBridge({ ...eventBridgeEvent, resources: ['arn:a', 'arn:b'] })).toEqual({
      trigger: {
        type: 'eventbridge',
        source: 'mapfre.apolices',
        detail_type: 'ApoliceEmitida',
        event_id: 'eb-1',
        event_time: '2026-10-22T10:00:00Z',
        resources_count: 2,
      },
    });
  });

  it('deixa resources_count undefined quando resources não é array', () => {
    const { resources: _resources, ...semResources } = eventBridgeEvent;
    expect((enrichEventBridge(semResources).trigger as Record<string, unknown>).resources_count).toBeUndefined();
  });
});

describe('batchResultFields', () => {
  it('conta as falhas parciais e lista os IDs (até 10)', () => {
    const batchItemFailures = Array.from({ length: 11 }, (_, i) => ({ itemIdentifier: `m${i}` }));
    const out = batchResultFields({ batchItemFailures });
    expect((out.trigger as Record<string, unknown>).failed_count).toBe(11);
    expect((out.trigger as Record<string, unknown>).failed_ids).toHaveLength(10);
  });

  it.each([undefined, null, {}, { batchItemFailures: 'x' }])('retorna vazio sem batchItemFailures (%p)', (result) => {
    expect(batchResultFields(result)).toEqual({});
  });
});
