import {
  extractClientContextCorrelationId,
  extractCorrelationId,
} from '../../../../../../../../sources/code/lambdas/typescript/utils/wide-logger/enrichers/correlation';
import { apiV2Event, eventBridgeEvent, fakeContext, sqsEvent } from '../helpers';

const h = 'x-correlation-id';

describe('extractCorrelationId', () => {
  it('lê o header do API Gateway (case-insensitive)', () => {
    expect(extractCorrelationId(apiV2Event, h)).toBe('corr-1');
  });

  it('lê message attribute do SQS', () => {
    const ev = {
      Records: [{ eventSource: 'aws:sqs', messageAttributes: { correlationId: { stringValue: 'c-sqs', dataType: 'String' } } }],
    };
    expect(extractCorrelationId(ev, h)).toBe('c-sqs');
  });

  it('lê message attribute do SNS', () => {
    const ev = { Records: [{ EventSource: 'aws:sns', Sns: { MessageAttributes: { 'x-correlation-id': { Type: 'String', Value: 'c-sns' } } } }] };
    expect(extractCorrelationId(ev, h)).toBe('c-sns');
  });

  it('lê detail.correlationId do EventBridge', () => {
    expect(extractCorrelationId({ ...eventBridgeEvent, detail: { correlationId: 'c-eb' } }, h)).toBe('c-eb');
  });

  it('lê do payload em invocação direta', () => {
    expect(extractCorrelationId({ correlation_id: 'c-direct' }, h)).toBe('c-direct');
  });

  it('aceita ID numérico e remove espaços', () => {
    expect(extractCorrelationId({ correlationId: 123 }, h)).toBe('123');
    expect(extractCorrelationId({ headers: { 'x-correlation-id': '  c-1  ' } }, h)).toBe('c-1');
  });

  it('ignora IDs vazios ou de tipo inválido e segue para a próxima fonte', () => {
    expect(extractCorrelationId({ headers: { 'x-correlation-id': '   ' }, correlationId: 'c-payload' }, h)).toBe('c-payload');
    expect(extractCorrelationId({ correlationId: { id: 1 } }, h)).toBeUndefined();
  });

  it('ignora fontes que não são objetos', () => {
    expect(extractCorrelationId({ headers: 'texto', detail: 'texto', Records: [] }, h)).toBeUndefined();
  });

  it('retorna undefined quando não há', () => {
    expect(extractCorrelationId(sqsEvent, h)).toBeUndefined();
    expect(extractCorrelationId(null, h)).toBeUndefined();
    expect(extractCorrelationId('texto', h)).toBeUndefined();
  });
});

describe('extractClientContextCorrelationId', () => {
  it('lê Custom.correlationId do ClientContext', () => {
    expect(extractClientContextCorrelationId(fakeContext({ clientContext: { Custom: { correlationId: 'c-ctx' } } }), h)).toBe('c-ctx');
  });

  it('respeita o nome de header customizado', () => {
    const ctx = fakeContext({ clientContext: { Custom: { 'x-meu-id': 'c-custom' } } });
    expect(extractClientContextCorrelationId(ctx, 'x-meu-id')).toBe('c-custom');
  });

  it('retorna undefined sem context, ClientContext ou Custom', () => {
    expect(extractClientContextCorrelationId(undefined, h)).toBeUndefined();
    expect(extractClientContextCorrelationId(fakeContext(), h)).toBeUndefined();
    expect(extractClientContextCorrelationId(fakeContext({ clientContext: null }), h)).toBeUndefined();
    expect(extractClientContextCorrelationId(fakeContext({ clientContext: {} }), h)).toBeUndefined();
    const ctx = fakeContext({ clientContext: { Custom: 'texto' as unknown as Record<string, unknown> } });
    expect(extractClientContextCorrelationId(ctx, h)).toBeUndefined();
  });
});
